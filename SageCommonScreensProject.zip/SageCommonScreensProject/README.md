# Sage Space — Android Studio Java + XML

Simple sage-green and warm-cream themed assignment starter. Includes Splash, Login, Register, Forgot Password, Reset Password, Home grid and Profile.

Open this folder in Android Studio, allow Gradle sync, install SDK 35 if prompted, and run. Authentication/password reset are demo flows only; no backend is connected.
